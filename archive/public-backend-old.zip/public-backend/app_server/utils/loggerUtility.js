function logError(error){
    console.log(error);
}

module.exports = { logError }
