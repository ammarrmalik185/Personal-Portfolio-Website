module.exports.blogController = require('./blog.controller');
module.exports.projectController = require('./project.controller');
module.exports.portfolioController = require('./portfolio.controller');
module.exports.apiController = require('./api.controller');
