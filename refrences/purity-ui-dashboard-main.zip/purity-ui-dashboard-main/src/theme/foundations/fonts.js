export const font = {
    body: 'Roboto'
};